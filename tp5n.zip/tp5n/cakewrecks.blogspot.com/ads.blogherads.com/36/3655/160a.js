void("<script language=\"JavaScript\" type=\"text/javascript\" src=\"httpdisabled://c2586692.cdn.cloudfiles.rackspacecloud.com/toptxt-160.js\"><\/script>\n");
void("<script type=\"text/javascript\" src=\"httpdisabled://ads.blogherads.com/36/3655/160nh.js\"><\/script>\n");
void("<script type=\"text/javascript\" src=\"httpdisabled://ads.blogherads.com/36/3655/feedsc.js\"><\/script>\n");
