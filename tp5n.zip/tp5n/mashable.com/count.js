var DISQUSWIDGETS;

if (typeof DISQUSWIDGETS != 'undefined') {
    DISQUSWIDGETS.displayCount({"showReactions": false, "text": {"and": "and", "reactions": {"zero": "", "multiple": "", "one": ""}, "comments": {"zero": "0", "multiple": "{num}", "one": "1"}}, "counts": [{"uid": 1, "comments": 20}, {"uid": 0, "comments": 26}, {"uid": 3, "comments": 8}, {"uid": 2, "comments": 29}, {"uid": 5, "comments": 10}, {"uid": 4, "comments": 45}, {"uid": 7, "comments": 3}, {"uid": 6, "comments": 6}, {"uid": 9, "comments": 7}, {"uid": 8, "comments": 3}]});
}
