﻿// JavaScript Document
document.writeln("<div id=\"footer\">");
document.writeln("	<ol>");
document.writeln("	    <li><a href=\"http:\/\/www.wenming.cn\/syzhq\/gywm\/\" target=\"_blank\">关于我们<\/a>&nbsp;|&nbsp;<a href=\"http:\/\/www.wenming.cn\/syzhq\/gywm\/\" target=\"_blank\">联系我们<\/a>&nbsp;|&nbsp;<a href=\"http:\/\/www.wenming.cn\/syzhq\/wylj\/\" target=\"_blank\">我要链接<\/a>&nbsp;|&nbsp;<a href=\"http:\/\/www.wenming.cn\/syzhq\/rczp\/\" target=\"_blank\">人才招聘<\/a>&nbsp;|&nbsp;版权声明&nbsp;|&nbsp;<a href=\"http:\/\/www.wenming.cn\/syzhq\/lmwz\/\" target=\"_blank\">联盟网站<\/a>&nbsp;|&nbsp;<a href=\"http:\/\/mail.wenming.cn\" target=\"_blank\">文明邮箱<\/a>&nbsp;|&nbsp;<a href=\"http:\/\/archive.wenming.cn\" target=\"_blank\">旧版回顾<\/a><\/li>");
document.writeln("		<div class=\"hr_10\"><\/div>");
document.writeln("    	<li>中共中央宣传部&nbsp;中央文明办主办<\/li>");
document.writeln("		<li>新华通讯社协办&nbsp;&nbsp;新华网承办<\/li>");
document.writeln("		<li>中国文明网&nbsp;&copy;版权所有<\/li>");
document.writeln("        <li>京ICP备第030140号&nbsp;&nbsp;互联网新闻信息服务许可证号 1012010003<\/li>");
document.writeln("    <\/ol>");
document.writeln("<\/div>")

//统计代码

document.write(unescape("%3Cscript id='tr_statobj' src='../../../../webdig.js' type='text/javascript'%3E%3C/script%3E"));

var obj=document.getElementById("tr_statobj");
if(window.ActiveXObject){
	run();
}
else
	document.write(unescape("%3Cscript type='text/javascript'%3E wd_paramtracker('_wdxid=000000000000000000000000000000000000000000');%3C/script%3E"));

function run(){
	if(obj.readyState=='complete'){
		wd_paramtracker('_wdxid=000000000000000000000000000000000000000000');
	}
	else{
		window.setTimeout(run,50);
	}
}
