//��ģ��
function section(a1,a2,b1,b2,c1,c2,d1,d2,e1,e2,f1,f2,g1,g2,h1,h2,k1,k2,p1,p2){
	this.string0=a1;	this.link0=a2;
	this.string1=b1;	this.link1=b2;
	this.string2=c1;	this.link2=c2;
	this.string3=d1;	this.link3=d2;
	this.string4=e1;	this.link4=e2;
	this.string5=f1;		this.link5=f2;
	this.string6=g1;	this.link6=g2;
	this.string7=h1;	this.link7=h2;
	this.string8=k1;	this.link8=k2;
	this.string9=p1;    this.link9=p2;
}
//�������
function echoa(clicks){
	//�������
	void('<a href="' + prov.link0 + '" target="_blank">' + prov.string0 + '</a>');
	void('<a href="' + prov.link1 + '" target="_blank">' + prov.string1 + '</a>');
	void('<a href="' + prov.link2 + '" target="_blank">' + prov.string2 + '</a>');
	void('<a href="' + prov.link3 + '" target="_blank">' + prov.string3 + '</a>');
	void('<a href="' + prov.link4 + '" target="_blank">' + prov.string4 + '</a>');
}
function echob(clicks){
	//�������
	void('<a href="' + prov.link5 + '" target="_blank">' + prov.string5 + '</a>');
	void('<a href="' + prov.link6 + '" target="_blank">' + prov.string6 + '</a>');
	void('<a href="' + prov.link7 + '" target="_blank">' + prov.string7 + '</a>');
	void('<a href="' + prov.link8 + '" target="_blank">' + prov.string8 + '</a>');
	void('<a href="' + prov.link9 + '" target="_blank">' + prov.string9 + '</a>');
}